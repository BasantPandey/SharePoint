﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Administration;


namespace Multiple_Site_Collections.ListofSiteCollection
{
    public partial class ListofSiteCollectionUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                GetAllListOfSiteCollection();
        }


        
        public void GetListofSites(string SitecollectionURL)
        {
            SPWebCollection collWebsite = new SPSite(SitecollectionURL).AllWebs;
            for (int i = 0; i < collWebsite.Count; i++)
            {
                using (SPWeb oWebsite = collWebsite[i])
                {
                    SPListCollection collList = oWebsite.Lists;
                    int k = i; 
                    Label1.Text += "  &nbsp;&nbsp; " +  (k+1).ToString()  + "." + SPEncode.HtmlEncode(collWebsite[i].Title) + "<BR>";
                    for (int j = 0; j < collList.Count; j++)
                    {
                        Label1.Text += "  &nbsp;&nbsp; &nbsp;&nbsp; " + SPEncode.HtmlEncode(collList[j].Title) + "<BR>";
                    }
                }
            }
        }

        public void GetAllListOfSiteCollection()
        {
            foreach (SPWebApplication wa in SPWebService.ContentService.WebApplications)
            {
                int i = 0;
                Label1.Text += "Web Application Name:<b> " + wa.Name + "</b><BR>";
                foreach (SPSite siteCollection in wa.Sites)
                {
                    try
                    {
                        i++;
                        Label1.Text += "<b>" + i.ToString() + ". " + siteCollection.Url + "</b><BR>";
                        GetListofSites(siteCollection.Url);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Exception occured: {0}\r\n{1}", e.Message, e.StackTrace);
                    }
                    finally
                    {
                        siteCollection.Dispose();
                    }
                }
            }
        }



    }
}
