﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.IO;

namespace UploadDocuments.UploadDocument
{
    public partial class UploadDocumentUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            try
            {
                string localPath = txtLocalPath.Text; //Local path.
               // string sharePointSite = txtServerURL.Text; //SharePoint site URL.
                string documentLibraryName = txtLibraryName.Text; // SharePoint library name.

                string[] sharePointSiteCol = txtServerURL.Text.Split(new Char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);


                // Make an object of your SharePoint site.
                foreach (string sharePointSite in sharePointSiteCol)
                {
                    using (SPSite oSite = new SPSite(sharePointSite))
                    {
                        oSite.AllowUnsafeUpdates = true;
                        SPWeb oWeb = oSite.OpenWeb();
                        oWeb.AllowUnsafeUpdates = true;
                        CreateDirectories(localPath,
                            oWeb.Folders[documentLibraryName].SubFolders);
                    }
                }
                
                txtMsg.ForeColor = System.Drawing.Color.Blue;
                txtMsg.Text = "Document Uploaded Successfully";
            }
            catch (Exception ex)
            {
                txtMsg.ForeColor = System.Drawing.Color.Red;
                txtMsg.Text = ex.Message;

            }
        }

        private void CreateDirectories(string localPath, SPFolderCollection sPFolderCollection)
        {
            //Upload Multiple Files
            foreach (FileInfo oFI in new DirectoryInfo(localPath).GetFiles())
            {
                FileStream fileStream = File.OpenRead(oFI.FullName);
                SPFile spfile = sPFolderCollection.Folder.Files.Add
                            (oFI.Name, fileStream, true);
                spfile.Update();
            }

            //Upload Multiple Folders
            foreach (DirectoryInfo oDI in new DirectoryInfo(localPath).GetDirectories())
            {
                string sFolderName = oDI.FullName.Split('\\')
                            [oDI.FullName.Split('\\').Length - 1];
                SPFolder spNewFolder = sPFolderCollection.Add(sFolderName);
                spNewFolder.Update();
                //Recursive call to create child folder
                CreateDirectories(oDI.FullName, spNewFolder.SubFolders);
            }

        }
    }
}
